Machine Learning Lab Project

Title: Cricket data analysis using web scraping

How to run this project:
Unzip this folder and run Exploratory data analysis.ipynb file in jupyter notebook


submitted by - Anurag Singh Sapid: 500083382
               Avani Vaish   Sapid: 500082636 

